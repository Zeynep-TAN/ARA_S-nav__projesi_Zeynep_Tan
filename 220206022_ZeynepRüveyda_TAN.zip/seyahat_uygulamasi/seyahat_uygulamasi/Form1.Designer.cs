﻿namespace seyahat_uygulamasi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnbilet = new Button();
            btnotel = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnbilet
            // 
            btnbilet.BackColor = Color.Bisque;
            btnbilet.Location = new Point(75, 21);
            btnbilet.Name = "btnbilet";
            btnbilet.Size = new Size(212, 91);
            btnbilet.TabIndex = 1;
            btnbilet.Text = "Bilet Al";
            btnbilet.UseVisualStyleBackColor = false;
            btnbilet.Click += btnbilet_Click;
            // 
            // btnotel
            // 
            btnotel.BackColor = Color.Bisque;
            btnotel.Location = new Point(420, 21);
            btnotel.Name = "btnotel";
            btnotel.Size = new Size(192, 91);
            btnotel.TabIndex = 2;
            btnotel.Text = "Otel Kiralama";
            btnotel.UseVisualStyleBackColor = false;
            btnotel.Click += btnotel_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnbilet);
            panel1.Controls.Add(btnotel);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 140);
            panel1.TabIndex = 4;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightCyan;
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 140);
            panel2.Name = "panel2";
            panel2.Size = new Size(800, 446);
            panel2.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 586);
            Controls.Add(panel2);
            Controls.Add(panel1);
            IsMdiContainer = true;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button btnbilet;
        private Button btnotel;
        private Panel panel1;
        private Panel panel2;
    }
}
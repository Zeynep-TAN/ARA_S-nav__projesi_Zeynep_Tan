﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace seyahat_uygulamasi
{
    public partial class frmotel : Form
    {



        //string totalstring = string.Empty;
        public frmotel()
        {
            InitializeComponent();
        }

        private void o_kaydet_button_Click(object sender, EventArgs e)
        {
            if (int.TryParse(okisisayis_textBox.Text, out int kisi_sayisi))
            {
                int otel_fiyati = 500;


                int tutar = kisi_sayisi * otel_fiyati;


                MessageBox.Show($"Toplam Tutar: {tutar} ", "Toplam Tutar", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Kişi sayısı girilmedi", "geçersiz işlem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void frmotel_Load(object sender, EventArgs e)
        {

            SqlConnection baglanti = null;
            SqlCommand komut;
            SqlDataAdapter da;

            try
            {
                baglanti = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=M_bilet;Integrated Security=True");
                baglanti.Open();
                da = new SqlDataAdapter("SELECT * FROM M_Otel", baglanti);
                DataTable tablo = new DataTable();
                da.Fill(tablo);
                dataGridView1.DataSource = tablo;

            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            o_musterino_textBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            o_ad_textBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            o_soyad_textBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            sehir_textBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            oteladi_textBox.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            okisisayis_textBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            o_sifre_textBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();


        }
    }
}

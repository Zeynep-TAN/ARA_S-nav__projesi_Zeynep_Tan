namespace seyahat_uygulamasi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnbilet_Click(object sender, EventArgs e)
        {


            frmbilet biletal = new frmbilet();
            biletal.MdiParent = this;
            panel2.Controls.Add(biletal);//panele formlar� a�maya yarar.
            biletal.Show();

        }

        private void btnotel_Click(object sender, EventArgs e)
        {

            frmotel kirala = new frmotel();
            kirala.MdiParent = this;
            panel2.Controls.Add(kirala);
            kirala.Show();
        }
    }
}
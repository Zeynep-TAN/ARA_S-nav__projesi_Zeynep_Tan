﻿namespace seyahat_uygulamasi
{
    partial class frmotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            oteladi_textBox = new TextBox();
            o_sifre_textBox = new TextBox();
            o_soyad_textBox = new TextBox();
            o_ad_textBox = new TextBox();
            okisisayis_textBox = new TextBox();
            sehir_textBox = new TextBox();
            o_kaydet_button = new Button();
            label9 = new Label();
            dataGridView1 = new DataGridView();
            label10 = new Label();
            o_musterino_textBox = new TextBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(493, 138);
            label2.Name = "label2";
            label2.Size = new Size(151, 25);
            label2.TabIndex = 1;
            label2.Text = "Konaklanan Şehir:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(493, 201);
            label3.Name = "label3";
            label3.Size = new Size(81, 25);
            label3.TabIndex = 2;
            label3.Text = "Otel Adı:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(493, 266);
            label4.Name = "label4";
            label4.Size = new Size(91, 25);
            label4.TabIndex = 3;
            label4.Text = "Kişi Sayısı:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(452, 76);
            label5.Name = "label5";
            label5.Size = new Size(192, 25);
            label5.TabIndex = 4;
            label5.Text = "SATIN ALIM İŞLEMLERİ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(42, 201);
            label6.Name = "label6";
            label6.Size = new Size(49, 25);
            label6.TabIndex = 5;
            label6.Text = "Ad  :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(42, 275);
            label7.Name = "label7";
            label7.Size = new Size(66, 25);
            label7.TabIndex = 6;
            label7.Text = "Soyad:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(903, 198);
            label8.Name = "label8";
            label8.Size = new Size(56, 25);
            label8.TabIndex = 7;
            label8.Text = "Şifre :";
            // 
            // oteladi_textBox
            // 
            oteladi_textBox.Location = new Point(677, 195);
            oteladi_textBox.Name = "oteladi_textBox";
            oteladi_textBox.Size = new Size(150, 31);
            oteladi_textBox.TabIndex = 8;
            // 
            // o_sifre_textBox
            // 
            o_sifre_textBox.Location = new Point(1005, 195);
            o_sifre_textBox.Name = "o_sifre_textBox";
            o_sifre_textBox.Size = new Size(150, 31);
            o_sifre_textBox.TabIndex = 11;
            // 
            // o_soyad_textBox
            // 
            o_soyad_textBox.Location = new Point(201, 266);
            o_soyad_textBox.Name = "o_soyad_textBox";
            o_soyad_textBox.Size = new Size(150, 31);
            o_soyad_textBox.TabIndex = 12;
            // 
            // o_ad_textBox
            // 
            o_ad_textBox.Location = new Point(201, 207);
            o_ad_textBox.Name = "o_ad_textBox";
            o_ad_textBox.Size = new Size(150, 31);
            o_ad_textBox.TabIndex = 13;
            // 
            // okisisayis_textBox
            // 
            okisisayis_textBox.Location = new Point(677, 252);
            okisisayis_textBox.Name = "okisisayis_textBox";
            okisisayis_textBox.Size = new Size(150, 31);
            okisisayis_textBox.TabIndex = 14;
            // 
            // sehir_textBox
            // 
            sehir_textBox.Location = new Point(677, 135);
            sehir_textBox.Name = "sehir_textBox";
            sehir_textBox.Size = new Size(150, 31);
            sehir_textBox.TabIndex = 15;
            // 
            // o_kaydet_button
            // 
            o_kaydet_button.BackColor = Color.Bisque;
            o_kaydet_button.Location = new Point(532, 630);
            o_kaydet_button.Name = "o_kaydet_button";
            o_kaydet_button.Size = new Size(112, 34);
            o_kaydet_button.TabIndex = 16;
            o_kaydet_button.Text = "KAYDET";
            o_kaydet_button.UseVisualStyleBackColor = false;
            o_kaydet_button.Click += o_kaydet_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.LightCyan;
            label9.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(221, 28);
            label9.Name = "label9";
            label9.Size = new Size(691, 29);
            label9.TabIndex = 17;
            label9.Text = "FİYATLANDIRMA KİŞİ SAYISINA GÖREDİR.1 KİŞİ 500 TLDİR";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 356);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(1153, 225);
            dataGridView1.TabIndex = 18;
            dataGridView1.CellEnter += dataGridView1_CellEnter;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(42, 144);
            label10.Name = "label10";
            label10.Size = new Size(97, 25);
            label10.TabIndex = 19;
            label10.Text = "Müşteri no";
            // 
            // o_musterino_textBox
            // 
            o_musterino_textBox.Location = new Point(201, 138);
            o_musterino_textBox.Name = "o_musterino_textBox";
            o_musterino_textBox.Size = new Size(150, 31);
            o_musterino_textBox.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightCyan;
            label1.Location = new Point(141, 630);
            label1.Name = "label1";
            label1.Size = new Size(334, 25);
            label1.TabIndex = 21;
            label1.Text = "Toplam fiyatı görmek için kaydete basın .";
            // 
            // frmotel
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(1189, 689);
            Controls.Add(label1);
            Controls.Add(o_musterino_textBox);
            Controls.Add(label10);
            Controls.Add(dataGridView1);
            Controls.Add(label9);
            Controls.Add(o_kaydet_button);
            Controls.Add(sehir_textBox);
            Controls.Add(okisisayis_textBox);
            Controls.Add(o_ad_textBox);
            Controls.Add(o_soyad_textBox);
            Controls.Add(o_sifre_textBox);
            Controls.Add(oteladi_textBox);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "frmotel";
            Text = "frmotel";
            Load += frmotel_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox oteladi_textBox;
        private TextBox o_sifre_textBox;
        private TextBox o_soyad_textBox;
        private TextBox o_ad_textBox;
        private TextBox okisisayis_textBox;
        private TextBox sehir_textBox;
        private Button o_kaydet_button;
        private Label label9;
        private DataGridView dataGridView1;
        private Label label10;
        private TextBox o_musterino_textBox;
        private Label label1;
    }
}
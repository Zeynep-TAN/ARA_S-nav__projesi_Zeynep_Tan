﻿namespace seyahat_uygulamasi
{
    partial class frmbilet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            M_no_textBox = new TextBox();
            sehir_textBox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            Soyad_textBox = new TextBox();
            label8 = new Label();
            sifre_textBox = new TextBox();
            k_sayi_textBox = new TextBox();
            ad_textBox = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            btn_kaydet = new Button();
            dataGridView1 = new DataGridView();
            label3 = new Label();
            label7 = new Label();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Azure;
            groupBox2.Controls.Add(M_no_textBox);
            groupBox2.Controls.Add(sehir_textBox);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(Soyad_textBox);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(sifre_textBox);
            groupBox2.Controls.Add(k_sayi_textBox);
            groupBox2.Controls.Add(ad_textBox);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(36, 52);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(651, 342);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Satın Alım İşlemleri";
            // 
            // M_no_textBox
            // 
            M_no_textBox.Location = new Point(175, 49);
            M_no_textBox.Name = "M_no_textBox";
            M_no_textBox.Size = new Size(150, 31);
            M_no_textBox.TabIndex = 19;
            // 
            // sehir_textBox
            // 
            sehir_textBox.Location = new Point(175, 235);
            sehir_textBox.Name = "sehir_textBox";
            sehir_textBox.Size = new Size(150, 31);
            sehir_textBox.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 49);
            label2.Name = "label2";
            label2.Size = new Size(104, 25);
            label2.TabIndex = 17;
            label2.Text = "Müşteri No:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 235);
            label1.Name = "label1";
            label1.Size = new Size(55, 25);
            label1.TabIndex = 16;
            label1.Text = "Şehir:";
            // 
            // Soyad_textBox
            // 
            Soyad_textBox.Location = new Point(175, 136);
            Soyad_textBox.Name = "Soyad_textBox";
            Soyad_textBox.Size = new Size(150, 31);
            Soyad_textBox.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(21, 136);
            label8.Name = "label8";
            label8.Size = new Size(66, 25);
            label8.TabIndex = 14;
            label8.Text = "Soyad:";
            // 
            // sifre_textBox
            // 
            sifre_textBox.Location = new Point(175, 284);
            sifre_textBox.Name = "sifre_textBox";
            sifre_textBox.Size = new Size(150, 31);
            sifre_textBox.TabIndex = 12;
            // 
            // k_sayi_textBox
            // 
            k_sayi_textBox.Location = new Point(175, 189);
            k_sayi_textBox.Name = "k_sayi_textBox";
            k_sayi_textBox.Size = new Size(150, 31);
            k_sayi_textBox.TabIndex = 11;
            // 
            // ad_textBox
            // 
            ad_textBox.Location = new Point(175, 93);
            ad_textBox.Name = "ad_textBox";
            ad_textBox.Size = new Size(150, 31);
            ad_textBox.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(21, 284);
            label6.Name = "label6";
            label6.Size = new Size(51, 25);
            label6.TabIndex = 8;
            label6.Text = "Şifre:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 192);
            label5.Name = "label5";
            label5.Size = new Size(91, 25);
            label5.TabIndex = 7;
            label5.Text = "Kişi Sayısı:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 96);
            label4.Name = "label4";
            label4.Size = new Size(39, 25);
            label4.TabIndex = 6;
            label4.Text = "Ad:";
            // 
            // btn_kaydet
            // 
            btn_kaydet.BackColor = Color.Bisque;
            btn_kaydet.Location = new Point(834, 164);
            btn_kaydet.Name = "btn_kaydet";
            btn_kaydet.Size = new Size(112, 34);
            btn_kaydet.TabIndex = 2;
            btn_kaydet.Text = "Kaydet";
            btn_kaydet.UseVisualStyleBackColor = false;
            btn_kaydet.Click += btn_kaydet_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(57, 435);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(1070, 298);
            dataGridView1.TabIndex = 3;
            dataGridView1.CellEnter += dataGridView1_CellEnter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(313, 9);
            label3.Name = "label3";
            label3.Size = new Size(579, 28);
            label3.TabIndex = 4;
            label3.Text = "FİYATLANDIRMA KİŞİ SAYISINA GÖREDİR.1 KİŞİ 700 TL'DİR. ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(718, 107);
            label7.Name = "label7";
            label7.Size = new Size(334, 25);
            label7.TabIndex = 5;
            label7.Text = "Toplam fiyatı görmek için kaydete basın .";
            // 
            // frmbilet
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightBlue;
            ClientSize = new Size(1198, 776);
            Controls.Add(label7);
            Controls.Add(label3);
            Controls.Add(dataGridView1);
            Controls.Add(btn_kaydet);
            Controls.Add(groupBox2);
            Name = "frmbilet";
            Text = "frmbilet";
            Load += frmbilet_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private GroupBox groupBox2;
        private TextBox sifre_textBox;
        private TextBox sayi_textBox;
        private TextBox ad_textBox;
        private Label label6;
        private Label label5;
        private Label label4;
        private Button btn_kaydet;
        private TextBox Soyad_textBox;
        private Label label8;
        private TextBox k_sayi_textBox;
        private DataGridView dataGridView1;
        private TextBox M_no_textBox;
        private TextBox sehir_textBox;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label7;
    }
}